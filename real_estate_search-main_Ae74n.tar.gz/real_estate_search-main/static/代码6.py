from pyecharts import options as opts
from pyecharts.charts import Geo
import pandas as pd
from pyecharts.options import TextStyleOpts

csvFilename = 'D:\城市房价.csv'
province_list = []
price_list = []
df = pd.read_csv(csvFilename)
province_list = df['省会名称'].tolist()
price_list = df['价格'].tolist()
# 生成全国各省市平均房价显示图

c = (
    Geo(
        # 设置生成的div及页面属性
        init_opts=opts.InitOpts(
            width='1700px',
            height='750px',
            page_title='全国各省市平均房价',
        ))
    .add_schema(maptype="china")
    .add_coordinate('保亭', 109.70259, 18.63905)
    .add_coordinate('乐东', 109.17361, 18.74986)
    .add_coordinate('陵水', 110.0372, 18.50596)
    .add("城市名", [list(z) for z in zip(province_list, price_list)])
    .set_series_opts(
        label_opts=opts.LabelOpts(
            is_show=True,
            formatter='{b}',

        )
    )
    .set_global_opts(
        visualmap_opts=opts.VisualMapOpts(
            is_piecewise=True,
            min_=0,
            max_=60000,
            range_size=10000
        ),
        title_opts=opts.TitleOpts(
            title="全国各省市平均房价",
            # title_link='http://www.baidu.com',  # 点击标题跳转链接
            # title_target=,    #链接对应新窗口的打开方式  _blank _self
            # subtitle=,
            # subtitle_link=,
            # subtitle_target=,
            # item_gap=10,    #主副标题之间的间距。
            # title_textstyle_opts={
            #     'color':'#dd23fb',
            #
            # },       #标题样式  是个字典
            # subtitle_textstyle_opts={
            #
            # },       #副标题样式  是个字典

        ),
        legend_opts=opts.LegendOpts(
            legend_icon='circle',

        ),
        tooltip_opts=opts.TooltipOpts(
            is_show=True,
            trigger='item',
            axis_pointer_type='cross',
            is_always_show_content=False,
            # position=['10%','10%'],
            # formatter='{b0}: {c0}<br />{b1}: {c1}'
            textstyle_opts=TextStyleOpts()
        ),

    )
        .render("全国各省市平均房价.html")
)




