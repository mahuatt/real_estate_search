from templates.config import conn
import pymysql
def create_connection():
    return pymysql.connect(
        host='120.46.3.93',
        user='root',
        passwd='0411mtxM+',
        database='user'
    )


cur = conn.cursor()

def get_user_level(username):
    connection = create_connection()
    cursor = connection.cursor()
    query = "SELECT user_level FROM all_user WHERE user_name = %s"
    cursor.execute(query, (username,))
    level = cursor.fetchone()[0]
    cursor.close()
    connection.close()
    return level

def is_null(username,password):
	if(username==''or password==''):
		return True
	else:
		return False


def is_existed(username,password):
	sql="SELECT * FROM all_user WHERE user_name ='%s' and user_password ='%s'" %(username,password)
	conn.ping(reconnect=True)
	cur.execute(sql)
	conn.commit()
	result = cur.fetchall()
	if (len(result) == 0):
		return False
	else:
		return True

def exist_user(username):
	sql = "SELECT * FROM all_user WHERE user_name ='%s'" % (username)
	conn.ping(reconnect=True)
	cur.execute(sql)
	conn.commit()
	result = cur.fetchall()
	if (len(result) == 0):
		return False
	else:
		return True


