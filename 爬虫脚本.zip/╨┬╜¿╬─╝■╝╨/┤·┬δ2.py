from bs4 import BeautifulSoup
import requests
import random
import time
import csv
import math


# 链家【新房】链接的入口地址
url = 'https://bj.fang.lianjia.com/'
Agent = [
    'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0',
    'Mozilla/5.0 (X11; U; Linux x86_64; zh-CN; rv:1.9.2.10) Gecko/20100922 Ubuntu/10.10 (maverick) Firefox/3.6.10',
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
    'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E)',
    'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36'
]
SumCount = 0  # 所有页面总共的房产数量
flag = True  # 控制值写入一次csv文件头
filename = '全国房产信息.csv'

title = ['省会名称', '楼盘名称', '所在区域', '详细地址', '室厅数量', '建筑面积', '价格']


# 生成response对象
def getResponse(u):
    try:
        user_agent = random.choice(Agent)
        headers = {'User-Agent': user_agent}
        r = requests.get(u, headers=headers)
        print('---------  ',r.status_code)
        # r.encoding = r.apparent_encoding

        # response.raise_for_statues()
    except Exception as e:
        return None
    return r


# 获取所有城市链接    存储在<li class="clear">  标签中 所有后代元素 保定
# 返回 包含所有{'城市名称':'链接'}的字典
def getHref(u):
    city_name_href_dict = {}
    r = getResponse(u)
    if (r != None) and (r.status_code == 200):
        html = r.text
        tagList = getTag(html, 'li.clear a')
        city_href_list = getAttributeFromTag(tagList, 'href')
        city_name_list = getAttributeFromTag(tagList, 'title')

        # 利用遍历，将城市名称和链接，添加至字典中
        for i in range(0, len(city_name_list)):
            key = city_name_list[i]
            href = city_href_list[i]
            value = "http:" + href + '/loupan/'
            city_name_href_dict[key] = value
        return city_name_href_dict
    else:
        print('获取所有城市链接时失败')
        return str(r.status_code)


# 获取最大页码    参数 ：地址
def getMaxPageNum(u):
    r = getResponse(u)
    maxPageNum = 0
    if (r != None ) and (r.status_code == 200):
        tag = getTag(r.text, 'div.page-box')
        # tag[0]['data-total-count']    tag[0]获取包含总房产数量的div对象， ['data-total-count']获取其身上的总房产数量属性值
        allPage = int(tag[0]['data-total-count'])
        maxPageNum = math.ceil(allPage / 10)

    return maxPageNum


# 获取页面标记组
def getTag(html, element):
    soup = BeautifulSoup(html, 'html.parser')
    tagList = soup.select(element)
    return tagList


# 获取一页内城市信息
def getCityInfo(city_TagList, p):
    global SumCount
    AllList = []  # 存储所有的list
    pageInsideCount = 0  # 一个页面内几条数据

    for tag in city_TagList:
        city_tag_list = []
        # 信息可能不存在
        try:
            # 获取信息
            provinceName = p
            cityName = tag.select('div.resblock-name a')
            cityLocation = tag.select('div.resblock-location span')
            cityAddress = tag.select('div.resblock-location a')
            cityRoom = tag.select('a.resblock-room span')  # 几室几厅
            cityArea = tag.select('div.resblock-area span')  # 建筑面积
            cityPrice = tag.select('div.resblock-price span.number')

            # 向列表中添加房产信息
            city_tag_list.append(provinceName)  # 省会名称
            city_tag_list.append(cityName[0].text)  # 依次添加每一个内容到list中
            city_tag_list.append(cityLocation[0].text)
            city_tag_list.append(cityAddress[0].text)
            city_tag_list.append(cityRoom[0].text)
            city_tag_list.append(cityArea[0].text)
            city_tag_list.append(cityPrice[0].text)
        except AttributeError as e:
            # 没有text属性
            print('没有获取到房产信息对象')
        except IndexError as e1:
            # 没有获取到某个标记，而导致[0]操作时，下标越界
            # 信息可能不存在，判断不存在则添加空串避免出错。
            if 0 == len(cityName):
                cityName = ['null']
            if 0 == len(cityLocation):
                cityLocation = ['null']
            if 0 == len(cityAddress):
                cityAddress = ['null']
            if 0 == len(cityRoom):
                cityRoom = ['null']
            if 0 == len(cityArea):
                cityArea = ['null']
            if 0 == len(cityPrice):
                cityPrice = ['null']
        AllList.append(city_tag_list)  # 将list放入AllList中  形成二维数组，一会便于写入csv
        pageInsideCount = pageInsideCount + 1

    SumCount = SumCount + pageInsideCount

    print("本页共" + str(pageInsideCount) + "条数据")
    return AllList


# 从标记组中获取某标签某属性包含的连接  存储到字典中返回
def getAttributeFromTag(tagList, attr):
    attr_list = []
    for tag in tagList:
        value = tag[attr]
        # value = "http:" + href + '/loupan/'        # 需要/loupan资源才能访问到房产信息首页页面
        attr_list.append(value)
    return attr_list


# 获取各个城市房产信息
def getBuildingInfo(c_dict):
    maxPageNum = 0
    # 文件名
    global filename
    key_list, value_list = [], []
    # 获取所有城市名
    for key in c_dict:
        key_list.append(key)
        value_list.append(c_dict[key])
    # c_list全部城市首页链接
    for city_url in value_list:
        # 获取当前城市最大页面数字
        maxPageNum = getMaxPageNum(city_url)
        # 遍历当前城市所有页面
        for pageNum in range(1, maxPageNum + 1):
            # 拼接所有页面地址
            r_city_url = city_url + '/pg' + str(pageNum)
            # city_response 每个城市对应的响应对象
            city_response = getResponse(r_city_url)
            if 200 == city_response.status_code:
                html = city_response.text
                # 这里去掉了选择其中的.has-results 部分，因为有的页面中li的类名仅为下方内容，并不包含.has-results 部分
                building_tagList = getTag(html,
                                          'ul.resblock-list-wrapper li.resblock-list.post_ulog_exposure_scroll')  # 每一个城市房产列表 所有的li
                # value_list.index() 获取指定元素下标   这里是获取下标之后，再获取key_list中对应下标的城市名称
                province = key_list[value_list.index(city_url)].split('房')[
                    0]  # key_list[value_list.index(city_url)] 内容为  xx房产网
                # 获取到所有li后获取其中的房屋信息    building_info_list是二维列表
                building_info_list = getCityInfo(building_tagList, province)  # 当前页面所有房屋信息的二维列表
            saveData(filename, building_info_list)
            print("获取【" + province + "】的第【" + str(pageNum) + "】页已经完成...")
            print('睡一秒...')
            time.sleep(1)
            print('继续！')
        print("【" + province + "】所有页已经完成...")
        print('睡一秒...')
        time.sleep(1)
        print('下一座城市！')
    print("全国共【" + str(SumCount) + "】条数据")
    # return building_info_list


# 保存数据
def saveData(fname, b_info_list):
    global title, flag
    with open(fname, 'a', newline='', encoding='utf-8') as f:
        csvFile = csv.writer(f)
        if flag:
            csvFile.writerow(title)
            flag = False
        csvFile.writerows(b_info_list)  # 写多行  也就是二维数组的时候用writerows()  一维数组用writerow()
    print('数据写入完成！')


# 获取所有城市链接
cityLinkList = getHref(url)
# 获取各个城市房产信息  二维列表
getBuildingInfo(cityLinkList)
import csv
import pandas as pd
import numpy


# 读取csv文件
def getCsvFile(csvName):
    dataFrame = pd.read_csv(csvName + '.csv')
    return dataFrame


# 处理数据
def processData(df):
    df_list = []
    df = df.drop_duplicates("楼盘名称")
    row_indexs = df[df['价格'] == '价格待定'].index.tolist()
    df = df.drop(axis=0, labels=row_indexs)
    # 分组
    # 是个生成器
    group = df['价格'].groupby(df['省会名称'])
    for g in group:
        result_list = []
        # g[1].tolist()  --  ['22000', nan, nan, nan, nan, nan, nan, '17000']  每个省会对应的房价列表
        l = g[1].tolist()
        # 高效去除nan
        while numpy.nan in l:
            l.remove(numpy.nan)
        # 把所有str转换为int
        l = [int(x) for x in l]
        # 求平均
        avg_l = float('%.2f' % numpy.mean(l))

        # 制作列表作为返回值使用
        # g[0]  --  省会名称
        result_list.append(g[0])
        result_list.append(avg_l)
        df_list.append(result_list)
    return df_list


# 存储处理后的csv文件
def saveCsvFile(csvData, csvName):
    title = ['省会名称', '价格']
    r_csvName = csvName + 'v1.csv'
    with open(r_csvName, 'w', newline='') as f:
        csvFile = csv.writer(f)
        csvFile.writerow(title)
        for i in csvData:
            csvFile.writerow(i)


csvFilename = '全国房产信息'
csv_df = getCsvFile(csvFilename)

result_df = processData(csv_df)
saveCsvFile(result_df, csvFilename)