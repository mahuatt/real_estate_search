#数据库连接配置
import pymysql

conn = pymysql.connect(
        host='120.46.3.93',
        port=3306,
        user='root',
        password='0411mtxM+',
        database='user'
    )
