from flask import Flask, request, render_template, redirect, url_for, session, jsonify
import pymysql
from model.check_login import is_existed, exist_user, is_null, get_user_level
from model.check_regist import add_user
from pyecharts import options as opts
from pyecharts.charts import Bar
import pandas as pd
import requests
import json

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # 用于会话管理，确保安全性

def create_connection():
    return pymysql.connect(
        host='120.46.3.93',
        user='root',
        passwd='0411mtxM+',
        database='real_estae'
    )

def create_connection_user():
    return pymysql.connect(
        host='120.46.3.93',
        user='root',
        passwd='0411mtxM+',
        database='user'
    )

def execute_query(connection, query):
    cursor = connection.cursor()
    try:
        cursor.execute(query)
        records = cursor.fetchall()
        return records
    except Exception as e:
        print(f"The error '{e}' occurred")
        return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/user_login', methods=['GET', 'POST'])
def user_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if is_null(username, password):
            login_message = "温馨提示：账号和密码是必填"
            return render_template('login.html', message=login_message)
        elif is_existed(username, password):
            session['username'] = username  # 设置会话
            return redirect(url_for('search'))
        elif exist_user(username):
            login_message = "温馨提示：密码错误，请输入正确密码"
            return render_template('login.html', message=login_message)
        else:
            login_message = "温馨提示：不存在该用户，请先注册"
            return render_template('login.html', message=login_message)
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if is_null(username, password):
            register_message = "温馨提示：账号和密码是必填"
            return render_template('register.html', message=register_message)
        elif exist_user(username):
            register_message = "温馨提示：用户已存在，请直接登录"
            return render_template('register.html', message=register_message)
        else:
            add_user(username, password)
            return redirect(url_for('user_login'))
    return render_template('register.html')

@app.route('/search', methods=['GET', 'POST'])
def search():
    if 'username' not in session:
        return redirect(url_for('user_login'))  # 未登录则重定向到登录页面

    user_level = get_user_level(session['username'])  # 获取用户等级

    if request.method == 'POST':
        province = request.form.get('province')
        building = request.form.get('building')
        region = request.form.get('region')

        conn = create_connection()
        if conn:
            query = "SELECT * FROM real_estate_price WHERE 1=1"
            if province:
                query += f" AND 省会名称 = '{province}'"
            if building:
                query += f" AND 楼盘名称 = '{building}'"
            if region:
                query += f" AND 所在区域 = '{region}'"
            
            records = execute_query(conn, query)
            conn.close()
            return render_template('result.html', records=records, user_level=user_level)
    return render_template('search.html', user_level=user_level)

@app.route('/compare', methods=['POST'])
def compare():
    if 'username' not in session:
        return redirect(url_for('user_login'))  # 未登录则重定向到登录页面

    user_level = get_user_level(session['username'])  # 获取用户等级

    if user_level == 0:
        return render_template('comparison.html', message="普通用户不能使用对比搜索，请升级为高级用户。")

    query1 = request.form.get('query1')
    query2 = request.form.get('query2')
    
    conn = create_connection()
    if conn:
        avg_price1 = get_average_price(conn, query1)
        avg_price2 = get_average_price(conn, query2)
        
        conn.close()
        
        if avg_price1 is not None and avg_price2 is not None:
            bar = Bar()
            bar.add_xaxis(["查询 1", "查询 2"])
            bar.add_yaxis("均价", [avg_price1, avg_price2])
            bar.set_global_opts(title_opts=opts.TitleOpts(title="平均房产价格"))
            
            bar_html = bar.render_embed()
            return render_template('comparison.html', bar_html=bar_html)
        else:
            return render_template('comparison.html', message="No results found for one or both queries.")
    return redirect(url_for('search'))

def get_average_price(connection, query):
    cursor = connection.cursor()
    try:
        conditions = query.split()
        where_clause = " AND ".join([f"{condition.split(':')[0]} = '{condition.split(':')[1]}'" for condition in conditions])
        query = f"SELECT AVG(价格) FROM real_estate_price WHERE {where_clause}"
        
        print(f"Executing query: {query}")  # 调试信息
        
        cursor.execute(query)
        avg_price = cursor.fetchone()[0]
        
        print(f"Query result: {avg_price}")  # 调试信息
        
        return avg_price
    except Exception as e:
        print(f"The error '{e}' occurred")
        return None
    finally:
        cursor.close()

@app.route('/upgrade')
def upgrade():
    if 'username' not in session:
        return redirect(url_for('user_login'))  # 未登录则重定向到登录页面
    return render_template('upgrade.html')

@app.route('/upgrade_complete', methods=['POST'])
def upgrade_complete():
    if 'username' not in session:
        return redirect(url_for('user_login'))  # 未登录则重定向到登录页面

    username = session['username']
    connection = create_connection_user()
    cursor = connection.cursor()
    query = "UPDATE all_user SET user_level = 1 WHERE user_name = %s"
    cursor.execute(query, (username,))
    connection.commit()
    cursor.close()
    connection.close()

    return redirect(url_for('search'))

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

@app.route('/wenxin')
def wenxin():
    return render_template('wenxin.html')

@app.route('/wenxin_ai', methods=['POST'])
def wenxin_ai():
    query = request.json.get('query')
    api_key = 'Qq2iXGsGhh6rB9O6pR8akhae'
    secret_key = '2VAmO9FWG7hdeDhiYQhtmyB2MN9uswh0'
    token_url = f'https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id={api_key}&client_secret={secret_key}'

    token_response = requests.post(token_url)
    if token_response.status_code == 200:
        access_token = token_response.json().get('access_token')
        if not access_token:
            print("Failed to get access token")
            return jsonify(result="获取 access_token 失败")
    else:
        print(f"Failed to get access token, status code: {token_response.status_code}, response: {token_response.text}")
        return jsonify(result="获取 access_token 失败")

    wenxin_url = f'https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions_pro?access_token={access_token}'
    headers = {'Content-Type': 'application/json'}
    data = {
        "messages": [
            {
                "role": "user",
                "content": query
            }
        ]
    }
    
    wenxin_response = requests.post(wenxin_url, headers=headers, json=data)
    print(f"Request sent to Wenxin: {data}")
    print(f"Wenxin response status code: {wenxin_response.status_code}")
    print(f"Wenxin response text: {wenxin_response.text}")
    
    result = wenxin_response.json()
    return jsonify(result=result.get('result', []))

if __name__ == '__main__':
    app.run(debug=True)
